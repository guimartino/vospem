<?php

	define("BOT_KEY", "SUA KEY");
	define("BOT_TOKEN", "minhasenha123");
	define("BOT_DOMINIO", "https://meusite.com/");
	define("BOT_ENDPOINT", BOT_DOMINIO."endpoint");