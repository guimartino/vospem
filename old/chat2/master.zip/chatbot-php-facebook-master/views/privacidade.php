<?php

    echo file_get_contents('views/privacidade.txt');