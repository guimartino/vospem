<?php

	define("BOT_KEY", "EAACqiqyhlGsBAKo4lK3vkIXmj5WwHW2SQy7UH9JdeSB7vqGZAgZCilnTJlMIwnibow0QykjX9qLZBW0ZB2GaqkV2RiGoumhIlYq63tkfVgZAflIHIKlBZAqH8q1FEF0GD2VVeoj0yYU8ihKFCUKjz33zV13JXsctajZA61MxZBQ5BepyF5TdBDoB");
	define("BOT_TOKEN", "minhasenha123");
	define("BOT_DOMINIO", "https://vospem.servermine.com.br/");
	define("BOT_ENDPOINT", BOT_DOMINIO."endpoint");