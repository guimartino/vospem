<?php

    echo file_get_contents("views/termos.txt");