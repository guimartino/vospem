<?php

header('Location: https://vospem.com/chat/f/login.php');
 ?>
